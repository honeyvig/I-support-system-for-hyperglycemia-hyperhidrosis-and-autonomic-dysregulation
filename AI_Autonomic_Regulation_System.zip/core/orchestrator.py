class Orchestrator:
    def route(self, signals):
        if signals.get('red_flag'):
            return 'Alert clinician'
        if signals.get('sympathetic_load'):
            return 'Behavioral regulation'
        return 'Monitor'
