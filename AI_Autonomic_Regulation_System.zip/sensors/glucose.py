def analyze_glucose(series):
    return max(series) > 180
