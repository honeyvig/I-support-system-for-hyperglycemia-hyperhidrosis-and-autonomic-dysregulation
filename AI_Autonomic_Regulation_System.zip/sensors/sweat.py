def analyze_sweat(conductance):
    return conductance > 0.8
