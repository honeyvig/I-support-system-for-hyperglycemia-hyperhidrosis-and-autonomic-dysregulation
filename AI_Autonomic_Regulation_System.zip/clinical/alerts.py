def clinician_alert(reason):
    return f'Clinician notified: {reason}'
