# AI Autonomic Regulation System

Clinically grounded AI support framework for hyperglycemia and hyperhidrosis.
