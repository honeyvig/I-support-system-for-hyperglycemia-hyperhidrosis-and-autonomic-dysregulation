from sensors.glucose import analyze_glucose
from sensors.sweat import analyze_sweat

print(analyze_glucose([120,150,190]))
print(analyze_sweat(0.9))
