def predict_spike(data):
    return sum(data[-3:]) / 3
