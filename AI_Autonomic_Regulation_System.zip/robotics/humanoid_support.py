def breathing_guidance():
    return 'Guide slow breathing to reduce sympathetic tone'
