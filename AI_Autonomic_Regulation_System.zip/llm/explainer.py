def explain_trend(trend):
    return f'Pattern observed: {trend}. Follow clinician guidance.'
