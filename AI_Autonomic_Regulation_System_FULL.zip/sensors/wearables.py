# HRV, sweat, temp adapters
