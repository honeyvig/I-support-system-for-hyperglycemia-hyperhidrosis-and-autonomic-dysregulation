# CGM data adapter
