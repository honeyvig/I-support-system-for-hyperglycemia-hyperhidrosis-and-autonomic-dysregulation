# LSTM glucose spike prediction (pattern-only)
