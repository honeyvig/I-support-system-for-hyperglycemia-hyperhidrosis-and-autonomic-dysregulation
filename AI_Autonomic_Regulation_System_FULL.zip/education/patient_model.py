# Fear-free education logic
