# AI Autonomic Regulation System
Full hospital-grade demo repository.
