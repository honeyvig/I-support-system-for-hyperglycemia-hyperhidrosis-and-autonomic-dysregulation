# Patient-safe LLM explanations
